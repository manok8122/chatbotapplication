from flask import Flask, request, jsonify, session
from flask_cors import CORS
import openai
import os
from textblob import TextBlob  # For spell correction
from flask_session import Session  # For user memory
import pyttsx3  # For text-to-speech
import speech_recognition as sr  # For speech recognition
import threading  # For running TTS in parallel

def continuous_listen():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Chatbot is actively listening...")
        recognizer.adjust_for_ambient_noise(source)
        while True:
            try:
                audio = recognizer.listen(source)
                recognized_text = recognizer.recognize_google(audio)
                print(f"Recognized: {recognized_text}")
                if recognized_text:
                    process_voice_command(recognized_text)
            except sr.UnknownValueError:
                print("Sorry, I couldn't understand that.")
            except sr.RequestError:
                print("Could not request results, check your internet connection.")

def process_voice_command(user_voice_input):
    with app.app_context():
        data = {"message": user_voice_input}
        response = chat_internal(data)
        print(f"Chatbot Response: {response['response']}")
        speak_text(response['response'])

def chat_internal(data):
    user_message = data.get("message", "").strip().lower()
    
    if not user_message:
        return {"error": "No message provided"}
    
    # Correct any spelling mistakes in user input
    corrected_message = correct_text(user_message)
    
    # Retrieve chat history
    if 'chat_history' not in session:
        session['chat_history'] = []
    
    # Check predefined responses
    predefined_responses = {
  "hi": "Hello! How can I assist you today?",
    "hello": "Hi there! How can I help you?",
    "how are you": "I'm just a bot, but I'm here to help! How can I assist you?",
    "thanks": "You're welcome! Let me know if you need anything else.",
    "bye": "Goodbye! Have a great day!",
    # Administration Process
            # Administration Process
    "how can i apply for undergraduate courses at thiagarajar college":
        "Applications for undergraduate courses are available online on the college's official website. Candidates must register and submit the filled-in application through the online portal.",
    "what documents are required for the admission process":
        "The following documents are required during the admission process: Class 10 and 12 mark sheets, Transfer certificate, Conduct certificate, Community certificate, Recent passport-size photographs.",
    "is there an entrance exam for postgraduate admissions":
        "Yes, for certain postgraduate courses, candidates must take an entrance exam conducted by the university.",
    
    # College Placements
    "how does the placement cell assist students":
        "The placement cell at Thiagarajar College organizes on-campus and off-campus recruitment drives, provides training, and connects students with top recruiters.",
    "which companies recruit students from thiagarajar college":
        "Top recruiters include TCS, Cognizant, Infosys, Wipro, HDFC Bank, and L&T.",
    "what is the average salary package for graduates":
        "The average salary package varies based on the course and company, but generally ranges from 3-8 LPA.",
    
    # Facilities (Hostel, Library, Labs)
    "what are the hostel facilities like at thiagarajar college":
        "The college provides hostel facilities with well-maintained rooms, study areas, and dining facilities for both male and female students.",
    "does the college have a well-equipped library":
        "Yes, the college has a vast library with thousands of books, digital resources, and research materials for students.",
    "are laboratories available for practical learning":
        "Yes, the college has state-of-the-art labs for science, computer science, and research activities.",
    
    # Feedback
    "how does the college gather student feedback":
        "The college conducts regular surveys and feedback sessions to improve academic and campus life.",
    "is there a grievance redressal system for students":
        "Yes, students can voice their concerns through the grievance redressal cell for resolution.",
    
    # Sports, Cultural, and Other Events
    "what sports facilities are available at thiagarajar college":
        "The college has excellent sports facilities including grounds for football, cricket, basketball, and indoor games.",
    "does the college organize cultural events":
        "Yes, the college hosts annual cultural festivals, inter-college competitions, and student-run clubs for arts and music.",
    "are there any technical or innovation-related events":
        "Yes, various departments organize hackathons, tech fests, and workshops to encourage innovation.",
  # Attendence and rules 
  "What is the minimum attendance required?": "Students must maintain at least 75% attendance to appear for exams.",
  " What happens if my attendance is low?":" Students with less than 75% attendance may need to provide a valid reason or attend extra classes.",
  "Are mobile phones allowed in class?" : " Mobile phones are not allowed inside classrooms unless permitted for academic purposes.",
   "how can i access the lms portal" : "You can access the LMS portal by visiting the official website and logging in with your student credentials.",  
   "what should i do if i forget my lms password":  "Click on 'Forgot Password' on the LMS login page and follow the instructions to reset your password.",
    }
    
    if corrected_message in predefined_responses:
        response_text = predefined_responses[corrected_message]
    else:
        # AI response
        try:
            response = openai.ChatCompletion.create(
                model="gpt-4-turbo",
                messages=session['chat_history'] + [{"role": "user", "content": corrected_message}]
            )
            response_text = response["choices"][0]["message"]["content"].strip()
        except Exception as e:
            response_text = "I'm sorry, I don't have information on that. Please visit the official website for more details."
    
    # Store message in session memory
    session['chat_history'].append({"role": "user", "content": user_message})
    session['chat_history'].append({"role": "assistant", "content": response_text})
    
    return {"response": response_text}

app = Flask(__name__)
CORS(app)

app.config["SESSION_TYPE"] = "filesystem"
Session(app)

openai.api_key = os.getenv("AIzaSyAxEtad7XB0wUcuofPPFnBKG9hQuM9DHL0")

# Initialize Text-to-Speech engine
engine = pyttsx3.init()

def speak_text(text):
    def tts():
        engine.say(text)
        engine.runAndWait()
    
    tts_thread = threading.Thread(target=tts)
    tts_thread.start()

# Function to correct spelling
def correct_text(text):
    try:
        corrected_text = str(TextBlob(text).correct())
        return corrected_text if corrected_text.strip() else text  # Ensure non-empty correction
    except Exception as e:
        print(f"Spell correction error: {e}")
        return text  # Return original text in case of error

@app.route("/chat", methods=["POST"])
def chat():
    data = request.json
    return jsonify(chat_internal(data))

if __name__ == "__main__":
    # Start continuous voice recognition in a separate thread
    threading.Thread(target=continuous_listen, daemon=True).start()
    app.run(debug=True, port=5000)