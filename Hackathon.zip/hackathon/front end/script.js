document.addEventListener("DOMContentLoaded", function () {
    let chatBox = document.getElementById("messages");

    // Show the default welcome message (centered)
    let welcomeMessage = document.createElement("div");
    welcomeMessage.classList.add("welcome-message");
    welcomeMessage.innerText = "👋 Welcome to TCARTS Chatbot!\nAsk anything about the college.";
    chatBox.appendChild(welcomeMessage);

    // Function to add a chat message (user or bot)
    function addMessage(text, sender) {
        let messageDiv = document.createElement("div");
        messageDiv.classList.add(sender === "user" ? "user-message" : "bot-message");

        // Get current time
        let time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        // Add message text and timestamp
        messageDiv.innerHTML = `<span>${text}</span><br><small>${time}</small>`;
        chatBox.appendChild(messageDiv);
        chatBox.scrollTop = chatBox.scrollHeight;
    }

    // Function to send a message
    window.sendMessage = function () {
        let userMessage = document.getElementById("userInput").value;
        if (!userMessage) return;

        addMessage(userMessage, "user");
        document.getElementById("userInput").value = "";

        fetch("http://127.0.0.1:5000/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message: userMessage })
        })
        .then(response => response.json())
        .then(data => {
            addMessage(data.response, "bot");
            speak(data.response); // Convert bot response to speech
        });
    };

    // Function for speech synthesis (bot speaking)
    function speak(text) {
        let speech = new SpeechSynthesisUtterance(text);
        speech.lang = "en-US";
        window.speechSynthesis.speak(speech);
    }

    // Function to start speech recognition (user speaking)
    window.startListening = function () {
        let recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
        recognition.lang = "en-US";
        recognition.start();

        recognition.onresult = function (event) {
            document.getElementById("userInput").value = event.results[0][0].transcript;
        };

        let audio = new Audio('notify.mp3');
        audio.play();
    };
});
